/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   polo_test.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nweizman <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/12/24 17:29:21 by nweizman          #+#    #+#             */
/*   Updated: 2016/12/24 17:29:24 by nweizman         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
** Test File: polo_test.c
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

//#include ""
//#include ""
//#include ""





int		main(int ac, char **av)
{
//	int	x = 0;
//	int y = 0;
//	char	*str;

//	(void)ac;
//	(void)av;







	return (0);
}

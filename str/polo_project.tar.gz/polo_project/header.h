/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nweizman <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/12/24 17:37:00 by nweizman          #+#    #+#             */
/*   Updated: 2016/12/24 17:37:01 by nweizman         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

// # include <sys/wait.h>
// # include <sys/stat.h>
// # include "gnl/get_next_line.h"

# include <stdbool.h>
# include "libft/ft_printf/ft_printf.h"

// typedef struct	s_stg
// {

// }				t_stg;






/*
** Functions
*/




#endif
